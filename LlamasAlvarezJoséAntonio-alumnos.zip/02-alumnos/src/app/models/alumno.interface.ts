export interface Alumno {
    id: string;
    nombre: string;
    apellidos: string;
    curso: string;
  }
