export interface Categoria{
    titulo:string;
}