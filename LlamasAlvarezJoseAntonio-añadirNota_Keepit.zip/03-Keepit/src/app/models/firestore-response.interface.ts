export interface FireStoreResponse<T> {
    id: string;
    data: T;
}