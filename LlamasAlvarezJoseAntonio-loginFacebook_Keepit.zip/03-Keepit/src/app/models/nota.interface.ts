export interface Nota{
    titulo: string;
    descripcion: string;
    categoriaId: string;
    categoriaNombre: string;
    userId: string;
}